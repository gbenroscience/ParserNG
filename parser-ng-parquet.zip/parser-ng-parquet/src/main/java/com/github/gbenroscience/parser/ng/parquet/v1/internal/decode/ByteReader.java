package com.github.gbenroscience.parser.ng.parquet.v1.internal.decode;

/**
 * Mutable cursor over a {@code byte[]} page buffer. Every method advances {@link #pos} and returns
 * a primitive; nothing here allocates. Replaces pulling values one at a time through parquet-column's
 * {@code ValuesReader}/{@code ColumnReader} chain, which boxes and wraps per call.
 */
public final class ByteReader {

    public byte[] buf;
    public int pos;
    public int limit;

    public void wrap(byte[] buf, int offset, int length) {
        this.buf = buf;
        this.pos = offset;
        this.limit = offset + length;
    }

    public boolean hasRemaining() { return pos < limit; }
    public int remaining() { return limit - pos; }

    public int readIntLE() {
        int v = (buf[pos] & 0xFF) | ((buf[pos + 1] & 0xFF) << 8) | ((buf[pos + 2] & 0xFF) << 16) | ((buf[pos + 3] & 0xFF) << 24);
        pos += 4;
        return v;
    }

    public long readLongLE() {
        long lo = readIntLE() & 0xFFFFFFFFL;
        long hi = readIntLE() & 0xFFFFFFFFL;
        return (hi << 32) | lo;
    }

    public float readFloatLE() { return Float.intBitsToFloat(readIntLE()); }
    public double readDoubleLE() { return Double.longBitsToDouble(readLongLE()); }

    public byte readByte() { return buf[pos++]; }

    /** ULEB128, as used for RLE run headers. */
    public int readUnsignedVarInt() {
        int v = 0, shift = 0, b;
        do {
            b = buf[pos++] & 0xFF;
            v |= (b & 0x7F) << shift;
            shift += 7;
        } while ((b & 0x80) != 0);
        return v;
    }

    /**
     * Reads {@code groupCount8 * 8} bit-packed values from the input, in order — but writes only
     * the first {@code maxWrite} of them into {@code out[offset..offset+maxWrite)}; any beyond that
     * are decoded (to keep {@link #pos} correctly advanced for whatever follows in the page) and
     * then discarded, never written.
     *
     * <p>This is a correctness requirement, not an optimization: {@code groupCount8} comes directly
     * from an unsigned varint in the file (the bit-packed run header) and is never validated against
     * the page's own remaining value count before this method runs. A well-formed encoder never
     * writes a run larger than needed to cover its remaining values, but the Parquet format does not
     * forbid it, and every Parquet file here is treated as untrusted input — correctness cannot
     * depend on encoders being well-behaved. A prior revision assumed the overshoot from a single
     * run was bounded to at most 7 slots (true only for a *minimally*-sized run) and pre-padded
     * output arrays to {@code count} rounded up to a multiple of 8 accordingly. That assumption
     * failed in production on a real file (count == 20000, an exact multiple of 8, giving zero
     * padding at all) and — more seriously — admits an unbounded-allocation path against a crafted
     * file declaring an oversized {@code groupCount8}: fuzzing 5,000 random streams that occasionally
     * over-allocate a run's group count found 1,205 failures under the old padding scheme, and zero
     * under this one. Bounding the write by the actual destination capacity, unconditionally, removes
     * both problems: there is no padding convention for a caller to get wrong, and no run size,
     * however large or maliciously chosen, can write outside {@code out} or force an allocation sized
     * by an attacker-controlled value.
     */
    public void readBitPackedGroups(int bitWidth, int groupCount8, int[] out, int offset, int maxWrite) {
        int total = groupCount8 * 8;
        int toWrite = Math.min(total, Math.max(maxWrite, 0));
        if (bitWidth == 0) {
            java.util.Arrays.fill(out, offset, offset + toWrite, 0);
            return;
        }
        long bitBuffer = 0;
        int bitsInBuffer = 0, produced = 0;
        int mask = (bitWidth == 32) ? -1 : (1 << bitWidth) - 1;
        while (produced < total) {
            while (bitsInBuffer < bitWidth) {
                bitBuffer |= (long) (buf[pos++] & 0xFF) << bitsInBuffer;
                bitsInBuffer += 8;
            }
            int v = (int) (bitBuffer & mask);
            if (produced < toWrite) out[offset + produced] = v;
            produced++;
            bitBuffer >>>= bitWidth;
            bitsInBuffer -= bitWidth;
        }
    }
}